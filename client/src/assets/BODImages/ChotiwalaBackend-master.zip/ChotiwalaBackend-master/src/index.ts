// src/server.ts
import 'dotenv/config'
import express from 'express'
import cors from 'cors'
import { connectDB } from './config/db'
import authRoutes from './routes/authRoutes'
import menuRoutes from './routes/menuRoutes'
import orderRoutes from './routes/orderRoutes'
import adminRoutes from './routes/adminRoutes'
import paymentsRoutes, {
  paymentsWebhookHandler,
} from './routes/paymentRoutes'
import { errorHandler } from './middleware/errorHandler'

const app = express()

const frontendOrigin =
  process.env.FRONTEND_ORIGIN || 'http://localhost:5173'

const corsOptions: cors.CorsOptions = {
  origin: frontendOrigin,
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization'],
}

app.use(cors(corsOptions))
app.options('*', cors(corsOptions))

// ⚠️ Stripe webhook MUST use raw body, so register it BEFORE express.json
app.post(
  '/api/payments/webhook',
  express.raw({ type: 'application/json' }),
  paymentsWebhookHandler,
)

// All other routes use JSON
app.use(express.json())

// Health check
app.get('/api/health', (_req, res) => {
  res.json({ status: 'ok' })
})

// Routes
app.use('/api/auth', authRoutes)
app.use('/api/menu', menuRoutes)
app.use('/api/orders', orderRoutes)
app.use('/api/admin', adminRoutes)
app.use('/api/payments', paymentsRoutes)

// Error handler
app.use(errorHandler)

const PORT = process.env.PORT || 4000

connectDB().then(() => {
  app.listen(PORT, () => {
    console.log(`Server listening on http://localhost:${PORT}`)
  })
})
