import jwt, { SignOptions } from 'jsonwebtoken'

export interface JwtPayload {
  sub: string
  email: string
  role: 'admin' | 'customer'
}

export const signJwt = (payload: JwtPayload): string => {
  const secret = process.env.JWT_SECRET
  if (!secret) throw new Error('JWT_SECRET not set')

  const rawExpires = process.env.JWT_EXPIRES_IN
  const expiresIn: SignOptions['expiresIn'] =
    (rawExpires as SignOptions['expiresIn']) ?? '7d'

  const options: SignOptions = { expiresIn }

  return jwt.sign(payload, secret as jwt.Secret, options)
}

export const verifyJwt = (token: string): JwtPayload => {
  const secret = process.env.JWT_SECRET
  if (!secret) throw new Error('JWT_SECRET not set')

  return jwt.verify(token, secret as jwt.Secret) as JwtPayload
}
