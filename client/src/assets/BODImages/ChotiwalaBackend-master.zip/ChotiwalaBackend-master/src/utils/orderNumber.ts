// let counter = 1

// export const generateOrderNumber = (): string => {
//   // Very simple for now. You can replace with DB-based sequence later.
//   const padded = counter.toString().padStart(3, '0')
//   counter += 1
//   return `ORD-${padded}`
// }

// src/utils/orderNumber.ts
import crypto from 'crypto'

export const generateOrderNumber = (): string => {
  const now = new Date()
  const yy = now.getFullYear().toString().slice(-2)
  const mm = String(now.getMonth() + 1).padStart(2, '0')
  const dd = String(now.getDate()).padStart(2, '0')
  const rand = crypto.randomInt(0, 9999).toString().padStart(4, '0')

  // Example: ORD-251208-0342
  return `ORD-${yy}${mm}${dd}-${rand}`
}
