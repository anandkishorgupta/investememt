// backend/src/seed/seedMenu.ts
import mongoose from 'mongoose'
import dotenv from 'dotenv'
import { MenuSection } from '../models/MenuSection'
import { seedMenuSections } from './menuData'

dotenv.config()

async function run() {
  const uri = process.env.MONGO_URI
  if (!uri) {
    console.error('MONGO_URI not set')
    process.exit(1)
  }

  await mongoose.connect(uri)
  console.log('✅ Connected to MongoDB')

  // Optional: clear existing menu
  await MenuSection.deleteMany({})
  console.log('🧹 Cleared existing menu sections')

  await  MenuSection.insertMany(seedMenuSections)
  console.log('🍛 Seeded menu sections:', seedMenuSections.length)

  await mongoose.disconnect()
  process.exit(0)
}

run().catch((err) => {
  console.error(err)
  process.exit(1)
})
