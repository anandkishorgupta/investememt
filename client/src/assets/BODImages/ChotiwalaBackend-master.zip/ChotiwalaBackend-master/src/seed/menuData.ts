// backend/src/seed/menuData.ts
export const seedMenuSections = [
  // -----------------------------
  // ENTRÉES – VEGETARIAN
  // -----------------------------
  {
    id: "entrees-veg",
    title: "Vegetarian Entrée",
    badge: "STARTERS",
    items: [
      {
        id: "veg-samosa",
        name: "Vegetable Samosa (2 pcs)",
        description:
          "Crispy pyramid-shaped pastry filled with spiced potatoes and green peas, deep-fried until golden.",
        price: 7.9,

      },
      {
        id: "aloo-tikki",
        name: "Aloo Tikki (2 pcs)",
        description:
          "Fried potato patties stuffed with green peas and seasoned with aromatic spices.",
        price: 7.9,

      },
      {
        id: "onion-bhaji",
        name: "Onion Bhaji (2 pcs) (V)",
        description:
          "Crispy fritters made with onions coated in chickpeas flour batter, deep-fried to perfection.",
        price: 7.5,
      },
      {
        id: "samosa-chaat",
        name: "Samosa Chaat",
        description:
          "Deconstructed vegetable samosa served with curried chickpeas, yoghurt, mint sauce, tamarind chutney and crunchy homemade crisps.",
        price: 11.9,
      },
      {
        id: "aloo-tikki-chaat",
        name: "Aloo Tikki Chaat",
        description:
          "Spiced potato patties topped with curried chickpeas, yoghurt, mint sauce, tamarind chutney and crispy garnishes.",
        price: 11.9,
      },
      {
        id: "fries",
        name: "Fries",
        description: "Crispy fries.",
        price: 4.9,
      },
    ],
  },

  // -----------------------------
  // ENTRÉES – NON VEGETARIAN
  // -----------------------------
  {
    id: "entrees-nonveg",
    title: "Non-Vegetarian Entrée",
    badge: "STARTERS",
    items: [
      {
        id: "lamb-samosa",
        name: "Lamb Samosa (2 pcs)",
        description:
          "Homemade pastry filled with minced lamb, potatoes and peas, deep-fried until golden.",
        price: 10.5,
      },
      {
        id: "chicken-tikka",
        name: "Chicken Tikka (4 pcs)",
        description:
          "Succulent chicken pieces marinated in yoghurt, herbs and spices, cooked in the tandoor.",
        price: 15.9,
      },
      {
        id: "chicken-nuggets",
        name: "Chicken Nuggets",
        description: "Golden fried chicken nuggets.",
        price: 9.9,
      },
    ],
  },

  // -----------------------------
  // MAIN COURSE – CHICKEN
  // -----------------------------
  {
    id: "chicken-mains",
    title: "Main Course – Chicken",
    badge: "CHICKEN CURRIES",
    items: [
      {
        id: "butter-chicken",
        name: "Butter Chicken",
        description:
          "Chargrilled chicken simmered in a velvety tomato, cashew and cream gravy, infused with fenugreek.",
        price: 16.9,
      },
      {
        id: "chicken-tikka-masala",
        name: "Chicken Tikka Masala",
        description:
          "Chargrilled chicken sautéed with onions and capsicum, cooked in a spiced tomato and onion sauce.",
        price: 16.9,
      },
      {
        id: "chicken-methi-malai",
        name: "Chicken Methi Malai",
        description:
          "Tender chicken cooked in a creamy onion-based sauce flavoured with crushed fenugreek leaves.",
        price: 16.9,
      },
      {
        id: "mango-chicken",
        name: "Mango Chicken",
        description:
          "Succulent chicken pieces in a luscious mango-infused cream sauce with Indian spices.",
        price: 16.9,
      },
      {
        id: "chicken-madras",
        name: "Chicken Madras",
        description:
          "Southern-style chicken curry with onion-tomato gravy, mustard seeds, tamarind and coconut.",
        price: 16.9,
      },
      {
        id: "chicken-korma",
        name: "Chicken Korma",
        description:
          "Mild fragrant curry cooked in creamy onion and cashew sauce scented with cardamom.",
        price: 16.9,
      },
      {
        id: "chicken-vindaloo",
        name: "Chicken Vindaloo",
        description:
          "A Goan-style spicy curry with boneless chicken simmered in a fiery, tangy vindaloo sauce.",
        price: 16.9,
      },
      {
        id: "kadhai-chicken",
        name: "Kadhai Chicken",
        description:
          "Diced chicken tossed with peppers in a thick tomato-onion masala with roasted spices.",
        price: 16.9,
      },
      {
        id: "chicken-curry",
        name: "Chicken Curry",
        description:
          "Homestyle curry made with onions, tomatoes and signature spices.",
        price: 16.9,
      },
    ],
  },

  // -----------------------------
  // MAIN COURSE – LAMB
  // -----------------------------
  {
    id: "lamb-mains",
    title: "Main Course – Lamb",
    badge: "LAMB CURRIES",
    items: [
      {
        id: "lamb-rogan-josh",
        name: "Lamb Rogan Josh",
        description:
          "Kashmiri-style lamb simmered in spices, tomatoes and onions.",
        price: 17.9,
      },
      {
        id: "lamb-madras",
        name: "Lamb Madras",
        description:
          "South Indian curry with tender lamb cooked in coconut gravy.",
        price: 17.9,
      },
      {
        id: "lamb-korma",
        name: "Lamb Korma",
        description:
          "Mild creamy onion, tomato & cashew gravy scented with cardamom.",
        price: 17.9,
      },
      {
        id: "lamb-vindaloo",
        name: "Lamb Vindaloo",
        description:
          "Fiery Goan lamb curry cooked in tangy vindaloo sauce.",
        price: 17.9,
      },
      {
        id: "lamb-methi-malai",
        name: "Lamb Methi Malai",
        description:
          "Rich creamy onion-based sauce with fenugreek leaves.",
        price: 17.9,
      },
      {
        id: "lamb-masala",
        name: "Lamb Masala",
        description:
          "Lamb tossed with peppers in thick onion-tomato gravy.",
        price: 17.9,
      },
      {
        id: "lamb-potato",
        name: "Lamb Potato Curry",
        description:
          "Lamb cooked with potatoes in a rich onion-tomato masala.",
        price: 17.9,
      },
    ],
  },

  // -----------------------------
  // VEGETARIAN – LENTILS & CHICKPEAS
  // -----------------------------
  {
    id: "veg-lentils",
    title: "Vegetarian (Lentils & Chickpeas)",
    badge: "VEG CURRIES",
    items: [
      {
        id: "dal-tadka",
        name: "Dal Tadka (V)",
        description:
          "Yellow lentils tempered with cumin, garlic, tomatoes and coriander.",
        price: 14.9,
      },
      {
        id: "dal-dhaba",
        name: "Dal Dhaba",
        description:
          "Mixed lentils slow cooked with onion, tomatoes, garlic and fenugreek.",
        price: 14.9,
      },
      {
        id: "chana-masala",
        name: "Chana Masala (V)",
        description:
          "Chickpeas cooked with onions, tomatoes, garlic, ginger and spices.",
        price: 14.9,
      },
    ],
  },

  // -----------------------------
  // VEGETABLE CURRIES
  // -----------------------------
  {
    id: "veg-curries",
    title: "Vegetable Curries",
    badge: "VEG CURRIES",
    items: [
      {
        id: "veg-korma",
        name: "Vegetable Korma",
        description:
          "Mixed vegetables in a creamy cashew sauce with cardamom.",
        price: 15.9,
      },
      {
        id: "mix-veg",
        name: "Mix Vegetable Curry (V)",
        description: "A medley of vegetables cooked with herbs & spices.",
        price: 14.9,
      },
    ],
  },

  // -----------------------------
  // PANEER
  // -----------------------------
  {
    id: "paneer",
    title: "Paneer Specialties",
    badge: "PANEER",
    items: [
      {
        id: "kadhai-paneer",
        name: "Kadhai Paneer",
        description:
          "Paneer cubes with peppers in a spiced tomato-onion gravy.",
        price: 16.5,
      },
      {
        id: "mutter-paneer",
        name: "Mutter Paneer",
        description:
          "Paneer with peas in cumin, garlic & ginger tomato sauce.",
        price: 16.5,
      },
      {
        id: "saag-paneer",
        name: "Saag Paneer",
        description:
          "Spinach purée cooked with paneer, onions, garlic & tomatoes.",
        price: 16.5,
      },
      {
        id: "paneer-methi-malai",
        name: "Paneer Methi Malai",
        description: "Paneer in creamy sauce with fenugreek leaves.",
        price: 16.5,
      },
      {
        id: "paneer-masala",
        name: "Paneer Masala",
        description:
          "Paneer served in a rich tomato-onion gravy with peppers.",
        price: 16.5,
      },
      {
        id: "paneer-makhani",
        name: "Paneer Makhani",
        description:
          "Paneer in buttery tomato-cashew gravy.",
        price: 16.5,
      },
    ],
  },

  // -----------------------------
  // POTATO & EGGPLANT
  // -----------------------------
  {
    id: "potato-eggplant",
    title: "Potato & Eggplant Favourites",
    badge: "VEG",
    items: [
      {
        id: "bombay-aloo",
        name: "Bombay Aloo (V)",
        description:
          "Potatoes tempered with cumin in spiced onion-tomato masala.",
        price: 14.9,
      },
      {
        id: "aloo-mutter",
        name: "Aloo Mutter (V)",
        description: "Potatoes & peas in tomato-onion gravy.",
        price: 14.9,
      },
      {
        id: "aloo-baingan",
        name: "Aloo Baingan (V)",
        description: "Eggplant & potatoes in tomato-onion sauce.",
        price: 14.9,
      },
    ],
  },

  // -----------------------------
  // MUSHROOM & SPINACH
  // -----------------------------
  {
    id: "mushroom-spinach",
    title: "Mushroom & Spinach Creations",
    badge: "VEG",
    items: [
      {
        id: "mushroom-methi",
        name: "Mushroom Methi Malai",
        description:
          "Mushrooms & peas in creamy fenugreek sauce.",
        price: 14.9,
      },
      {
        id: "mushroom-masala",
        name: "Mushroom Masala (V)",
        description:
          "Mushrooms & peppers in onion-tomato gravy.",
        price: 14.9,
      },
    ],
  },

  // -----------------------------
  // RICE
  // -----------------------------
  {
    id: "rice",
    title: "Rice",
    badge: "RICE",
    items: [
      {
        id: "plain-basmati",
        name: "Plain Basmati Rice",
        description: "Fragrant steamed long-grain rice.",
        price: 3.5,
      },
    ],
  },

  // -----------------------------
  // BIRYANI
  // -----------------------------
  {
    id: "biryani",
    title: "Biryani",
    badge: "BIRYANI",
    items: [
      {
        id: "veg-biryani",
        name: "Vegetarian Biryani (V)",
        description:
          "Basmati rice with spices, herbs & nuts cooked dum-style. Served with raita.",
        price: 15.9,
      },
      {
        id: "chicken-biryani",
        name: "Chicken Biryani",
        description:
          "Basmati rice cooked with tender chicken, spices & herbs. Served with raita.",
        price: 17.9,
      },
      {
        id: "lamb-biryani",
        name: "Lamb Biryani",
        description:
          "Fragrant rice with slow-cooked lamb, spices & herbs. Served with raita.",
        price: 18.9,
      },
    ],
  },

  // -----------------------------
  // NAAN & ROTI
  // -----------------------------
  {
    id: "naan-breads",
    title: "Naan Breads & Roti",
    badge: "BREADS",
    items: [
      { id: "plain-naan", name: "Plain Naan", description: "Plain flour bread cooked in tandoor.", price: 3.5 },
      { id: "garlic-naan", name: "Garlic Naan", description: "Tandoori naan with fresh garlic.", price: 4.0 },
      { id: "cheese-naan", name: "Cheese Naan", description: "Stuffed with melted cheese.", price: 5.0 },
      { id: "cheese-garlic-naan", name: "Cheese and Garlic Naan", description: "Cheese naan topped with garlic.", price: 5.5 },
      { id: "chilli-cheese-naan", name: "Chilli Cheese Naan", description: "Cheese & fresh green chillies.", price: 5.0 },
      { id: "peshawari-naan", name: "Peshawari Naan", description: "Stuffed with dry fruits, nuts and coconut.", price: 5.5 },
    ],
  },

  // -----------------------------
  // ACCOMPANIMENTS
  // -----------------------------
  {
    id: "accompaniments",
    title: "Accompaniments",
    badge: "SIDES",
    items: [
      { id: "chutney", name: "Chutney", description: "Mango / Mint / Tamarind.", price: 3.0 },
      { id: "pickle", name: "Pickle", description: "Mango / Mixed / Chilli.", price: 3.0 },
      { id: "papadums", name: "Papadums", description: "Crispy lentil wafers.", price: 3.5 },
      {
        id: "raita",
        name: "Raita",
        description: "Homemade yogurt blended with spices and cucumber.",
        price: 3.5,
      },
    ],
  },

  // -----------------------------
  // DRINKS
  // -----------------------------
  {
    id: "drinks",
    title: "Drinks",
    badge: "DRINKS",
    items: [
      { id: "mango-lassi", name: "Mango Lassi", description: "Homemade yogurt drink with mango flavour.", price: 5.5 },
      { id: "soft-drinks", name: "Soft Drinks (375 ml)", description: "Assorted soft drinks.", price: 3.5 },
    ],
  },

  // -----------------------------
  // DESSERTS
  // -----------------------------
  {
    id: "desserts",
    title: "Desserts",
    badge: "SWEETS",
    items: [
      {
        id: "gulab-jamun",
        name: "Gulab Jamun",
        description:
          "Golden fried condensed milk dumplings in elaichi-scented sugar syrup.",
        price: 5.5,
      },
      {
        id: "rasmalai",
        name: "Rasmalai",
        description:
          "Creamy milk dessert cakes flavoured with cardamom.",
        price: 5.5,
      },
    ],
  },
];
