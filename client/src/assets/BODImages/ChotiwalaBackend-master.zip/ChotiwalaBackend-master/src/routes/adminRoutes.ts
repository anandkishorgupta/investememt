// backend/src/routes/adminRoutes.ts
import { Router } from 'express'
import { authMiddleware, adminOnly } from '../middleware/auth'
import {
  listAdminOrders,
  updateOrderStatusAdmin,
} from '../controllers/orderController'
import {
  getOverviewStats,
  listCustomers,
} from '../controllers/adminController'

const router = Router()

router.use(authMiddleware, adminOnly)

router.get('/stats', getOverviewStats)
router.get('/orders', listAdminOrders)
router.patch('/orders/:id/status', updateOrderStatusAdmin)
router.get('/customers', listCustomers)

export default router
