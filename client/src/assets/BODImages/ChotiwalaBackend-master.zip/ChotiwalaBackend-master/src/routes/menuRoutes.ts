// backend/src/routes/menuRoutes.ts
import { Router } from 'express'
import {
  getPublicMenu,
  listMenuItemsAdmin,
  createMenuItem,
  updateMenuItem,
  deleteMenuItem,
} from '../controllers/menuController'
import { authMiddleware, adminOnly } from '../middleware/auth'

const router = Router()

// Public menu
router.get('/', getPublicMenu)

// Admin-only menu management
router.get('/admin', authMiddleware, adminOnly, listMenuItemsAdmin)
router.post('/admin', authMiddleware, adminOnly, createMenuItem)
router.put('/admin/:id', authMiddleware, adminOnly, updateMenuItem)
router.delete('/admin/:id', authMiddleware, adminOnly, deleteMenuItem)

export default router
