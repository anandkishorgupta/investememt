import { Router } from 'express'
import { authMiddleware } from '../middleware/auth'
import { createCashOrder, getMyOrders } from '../controllers/orderController'

const router = Router()

router.post('/', authMiddleware, createCashOrder)
router.get('/my', authMiddleware, getMyOrders)

export default router
