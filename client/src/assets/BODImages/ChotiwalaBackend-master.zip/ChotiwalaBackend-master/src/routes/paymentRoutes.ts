import { Router } from 'express'
import { authMiddleware } from '../middleware/auth'
import { createPaymentIntent, paymentsWebhookHandler } from '../controllers/paymentController'

const router = Router()

// Customer-facing: must be authenticated to link orders to userId
router.post('/create-intent', authMiddleware, createPaymentIntent)

export { paymentsWebhookHandler }
export default router
