// backend/src/controllers/orderController.ts
import { Response } from 'express'
import { Types } from 'mongoose'
import { AuthRequest } from '../middleware/auth'
import { Order, IOrder, PaymentStatus } from '../models/Order'
import { generateOrderNumber } from '../utils/orderNumber'
import { User } from '../models/User'

// ---------- Types from frontend payload ----------

interface CreateOrderItemPayload {
  id: string
  name: string
  price: number
  quantity: number
}

interface CreateOrderPayload {
  items: CreateOrderItemPayload[]
  customer: {
    name: string
    email: string
    phone: string
  }
  notes?: string
  paymentMethod: 'PayOnPickup'
  paymentStatus: 'Pending'
  isPaidOnline: boolean
}

// ---------- Helpers ----------

const mapOrderToAdminDto = (order: IOrder) => ({
  id: order._id.toString(),
  _id: order._id.toString(), // keep both to avoid breaking older frontend usage
  orderNumber: order.orderNumber,
  items: order.items.map((i) => ({
    menuItemId: i.menuItemId.toString(),
    name: i.name,
    price: i.price,
    quantity: i.quantity,
  })),
  subtotal: order.subtotal,
  // if your frontend uses `total`, keep it aligned:
  total: order.subtotal,
  paymentMethod: order.paymentMethod,
  paymentStatus: order.paymentStatus,
  isPaidOnline: order.isPaidOnline,
  status: order.status,
  customerName: order.customerName,
  customerEmail: order.customerEmail,
  customerPhone: order.customerPhone,
  notes: order.notes,
  createdAt: order.createdAt,
  updatedAt: order.updatedAt,
})

type OrdersDateFilter = 'today' | 'yesterday' | '7days' | 'all'

const buildDateRange = (dateFilter?: OrdersDateFilter) => {
  const now = new Date()
  const start = new Date(now)
  const end = new Date(now)

  // default: no filter
  if (!dateFilter || dateFilter === 'all') return null

  if (dateFilter === 'today') {
    start.setHours(0, 0, 0, 0)
    end.setHours(23, 59, 59, 999)
    return { start, end }
  }

  if (dateFilter === 'yesterday') {
    start.setDate(start.getDate() - 1)
    start.setHours(0, 0, 0, 0)
    end.setDate(end.getDate() - 1)
    end.setHours(23, 59, 59, 999)
    return { start, end }
  }

  if (dateFilter === '7days') {
    // last 7 days including today
    start.setDate(start.getDate() - 6)
    start.setHours(0, 0, 0, 0)
    end.setHours(23, 59, 59, 999)
    return { start, end }
  }

  return null
}

// Cursor format: base64(JSON.stringify({ createdAt: string, id: string }))
const encodeCursor = (createdAt: Date, id: Types.ObjectId) => {
  const payload = {
    createdAt: createdAt.toISOString(),
    id: id.toString(),
  }
  return Buffer.from(JSON.stringify(payload)).toString('base64')
}

const decodeCursor = (cursor: string) => {
  try {
    const raw = Buffer.from(cursor, 'base64').toString('utf8')
    const parsed = JSON.parse(raw)
    if (!parsed?.createdAt || !parsed?.id) return null
    return {
      createdAt: new Date(parsed.createdAt),
      id: new Types.ObjectId(parsed.id),
    }
  } catch {
    return null
  }
}

// ---------- Public: cash order ----------

// POST /api/orders
export const createCashOrder = async (req: AuthRequest, res: Response) => {
  const payload = req.body as CreateOrderPayload

  if (!payload.items || !payload.items.length) {
    return res.status(400).json({ message: 'No items in order' })
  }

  const { customer, notes } = payload
  if (!customer?.name || !customer?.email) {
    return res
      .status(400)
      .json({ message: 'Customer name and email are required' })
  }

  const subtotal = payload.items.reduce((sum, i) => sum + i.price * i.quantity, 0)

  const order = await Order.create({
    orderNumber: generateOrderNumber(),
    items: payload.items.map((i) => ({
      menuItemId: i.id,
      name: i.name,
      price: i.price,
      quantity: i.quantity,
    })),
    subtotal,

    paymentMethod: 'cash',
    paymentStatus: 'Pending',
    isPaidOnline: false,

    status: 'Pending',

    customerName: customer.name,
    customerEmail: customer.email,
    customerPhone: customer.phone,
    notes: notes || '',

    userId: req.user?.sub ?? undefined,
  })

  return res.status(201).json({
    id: order._id.toString(),
    orderNumber: order.orderNumber,
    items: order.items,
    subtotal: order.subtotal,
    status: order.status,
    createdAt: order.createdAt,
  })
}

// ---------- Public: my orders ----------

// GET /api/orders/my
export const getMyOrders = async (req: AuthRequest, res: Response) => {
  if (!req.user) {
    return res.status(401).json({ message: 'Unauthorized' })
  }

  const orders = await Order.find({ userId: req.user.sub })
    .sort({ createdAt: -1 })
    .lean()

  return res.json({
    orders: orders.map((o: any) => ({
      id: o._id.toString(),
      orderNumber: o.orderNumber,
      items: o.items,
      subtotal: o.subtotal,
      total: o.subtotal,
      status: o.status,
      paymentMethod: o.paymentMethod,
      paymentStatus: o.paymentStatus,
      isPaidOnline: o.isPaidOnline,
      createdAt: o.createdAt,
    })),
  })
}

// ---------- Admin: list orders (NOW PAGINATED) ----------
//
// GET /api/admin/orders
// Query params:
// - status=Pending|Completed
// - paymentMethod=cash|card
// - isPaidOnline=true|false
// - dateFilter=today|yesterday|7days|all
// - limit=25|50 (default 25, max 100)
// - cursor=<base64>
//
export const listAdminOrders = async (req: AuthRequest, res: Response) => {
  const {
    status,
    paymentMethod,
    isPaidOnline,
    dateFilter,
    limit,
    cursor,
  } = req.query as {
    status?: string
    paymentMethod?: string
    isPaidOnline?: string
    dateFilter?: OrdersDateFilter
    limit?: string
    cursor?: string
  }

  const filter: any = {}

  // keep existing logic
  if (status === 'Pending' || status === 'Completed') {
    filter.status = status
  }

  if (paymentMethod === 'cash' || paymentMethod === 'card') {
    filter.paymentMethod = paymentMethod
  }

  if (typeof isPaidOnline === 'string') {
    if (isPaidOnline === 'true' || isPaidOnline === 'false') {
      filter.isPaidOnline = isPaidOnline === 'true'
    }
  }

  const range = buildDateRange(dateFilter)
  if (range) {
    filter.createdAt = { $gte: range.start, $lte: range.end }
  }

  // pagination settings
  const pageSizeRaw = parseInt(limit || '25', 10)
  const pageSize = Math.min(Math.max(pageSizeRaw || 25, 1), 100)

  const decoded = cursor ? decodeCursor(cursor) : null

  // Cursor-based pagination: (createdAt, _id) descending
  // Fetch "older than" the cursor (since list is newest first)
  if (decoded) {
    filter.$or = [
      { createdAt: { $lt: decoded.createdAt } },
      { createdAt: decoded.createdAt, _id: { $lt: decoded.id } },
    ]
  }

  const rawOrders = await Order.find(filter)
    .sort({ createdAt: -1, _id: -1 })
    .limit(pageSize + 1) // fetch one extra to determine if there’s a next page
    .lean()

  const hasMore = rawOrders.length > pageSize
  const pageDocs = hasMore ? rawOrders.slice(0, pageSize) : rawOrders

  const orders = (pageDocs as unknown as IOrder[]).map(mapOrderToAdminDto)

  const last = pageDocs.length ? pageDocs[pageDocs.length - 1] : null
  const nextCursor =
    hasMore && last
      ? encodeCursor(new Date((last as any).createdAt), new Types.ObjectId((last as any)._id))
      : null

  return res.json({
    orders,
    pageSize,
    hasMore,
    nextCursor,
  })
}

// ---------- Admin: update status ----------

// PATCH /api/admin/orders/:id/status
// body: { status: 'Pending' | 'Completed', paymentStatus?: 'Pending' | 'Paid' | 'Failed' }
export const updateOrderStatusAdmin = async (req: AuthRequest, res: Response) => {
  const { id } = req.params
  const { status, paymentStatus } = req.body as {
    status: 'Pending' | 'Completed'
    paymentStatus?: PaymentStatus
  }

  if (status !== 'Pending' && status !== 'Completed') {
    return res.status(400).json({ message: 'Invalid status' })
  }

  const update: any = { status }
  if (paymentStatus) update.paymentStatus = paymentStatus

  const order = await Order.findByIdAndUpdate(id, update, { new: true }).lean()

  if (!order) {
    return res.status(404).json({ message: 'Order not found' })
  }

  return res.json(mapOrderToAdminDto(order as unknown as IOrder))
}

// ---------- Admin: dashboard stats ----------

export const getAdminDashboardStats = async (req: AuthRequest, res: Response) => {
  const now = new Date()
  const startOfDay = new Date(now)
  startOfDay.setHours(0, 0, 0, 0)

  const endOfDay = new Date(now)
  endOfDay.setHours(23, 59, 59, 999)

  const [ordersToday, pendingOrders, customersCount] = await Promise.all([
    Order.countDocuments({
      createdAt: { $gte: startOfDay, $lte: endOfDay },
    }),
    Order.countDocuments({ status: 'Pending' }),
    User.countDocuments({}),
  ])

  return res.json({
    ordersToday,
    pendingOrders,
    customersCount,
  })
}

// ---------- Admin: customers list ----------

export const listAdminCustomers = async (req: AuthRequest, res: Response) => {
  const orderStats = await Order.aggregate([
    {
      $group: {
        _id: '$userId',
        ordersCount: { $sum: 1 },
        lastOrderAt: { $max: '$createdAt' },
      },
    },
  ])

  const statsByUserId = new Map<string, { ordersCount: number; lastOrderAt: Date }>()
  orderStats.forEach((s: any) => {
    if (!s._id) return
    statsByUserId.set(String(s._id), {
      ordersCount: s.ordersCount,
      lastOrderAt: s.lastOrderAt,
    })
  })

  const users = await User.find().lean()

  const customers = users.map((u: any) => {
    const stats = statsByUserId.get(u._id.toString())
    return {
      id: u._id.toString(),
      name: u.name,
      email: u.email,
      ordersCount: stats?.ordersCount ?? 0,
      lastOrderAt: stats?.lastOrderAt ?? null,
    }
  })

  return res.json({ customers })
}
