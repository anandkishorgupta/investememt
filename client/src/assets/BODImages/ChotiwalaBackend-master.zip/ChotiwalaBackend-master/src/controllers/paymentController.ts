import { Response } from 'express'
import Stripe from 'stripe'
import { AuthRequest } from '../middleware/auth'
import { Order } from '../models/Order'
import { generateOrderNumber } from '../utils/orderNumber'

const stripeSecret = process.env.STRIPE_SECRET_KEY
console.log(
  'STRIPE_SECRET_KEY starts with:',
  stripeSecret?.slice(0, 16),
) 

if (!stripeSecret) {
  throw new Error('STRIPE_SECRET_KEY not set')
}

const stripe = new Stripe(stripeSecret, {
  apiVersion: '2024-06-20',
})

interface PaymentLineItem {
  id: string
  name: string
  price: number
  quantity: number
}

interface CreatePaymentIntentPayload {
  amount: number // dollars
  items: PaymentLineItem[]
  customer: {
    name: string
    email: string
    phone?: string
    notes?: string
  }
}

// POST /api/payments/create-intent
export const createPaymentIntent = async (
  req: AuthRequest,
  res: Response,
) => {
  const payload = req.body as CreatePaymentIntentPayload

  if (!payload.amount || payload.amount <= 0) {
    return res.status(400).json({ message: 'Invalid amount' })
  }

  if (!payload.items || !payload.items.length) {
    return res.status(400).json({ message: 'No items in payment' })
  }

  const { customer } = payload
  if (!customer?.name || !customer?.email) {
    return res
      .status(400)
      .json({ message: 'Customer name and email are required' })
  }

  const amountCents = Math.round(payload.amount * 100)

  const metadata: Record<string, string> = {
    customerName: customer.name,
    customerEmail: customer.email,
  }
  if (customer.phone) metadata.customerPhone = customer.phone
  if (customer.notes) metadata.notes = customer.notes

  metadata.items = JSON.stringify(
    payload.items.map((i) => ({
      id: i.id,
      name: i.name,
      price: i.price,
      quantity: i.quantity,
    })),
  )

  if (req.user?.sub) {
    metadata.userId = String(req.user.sub)
  }

  const intent = await stripe.paymentIntents.create({
    amount: amountCents,
    currency: 'aud',
    receipt_email: customer.email,
    metadata,
    automatic_payment_methods: {
      enabled: true,
    },
  })

  return res.json({ clientSecret: intent.client_secret })
}

// ---------- Webhook ----------

export const paymentsWebhookHandler = async (req: any, res: Response) => {
  const sig = req.headers['stripe-signature']
  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET

  if (!webhookSecret) {
    console.error('STRIPE_WEBHOOK_SECRET not set')
    return res.status(500).send('Webhook secret not configured')
  }

  if (!sig) {
    return res.status(400).send('Missing stripe-signature header')
  }

  let event: Stripe.Event

  try {
    event = stripe.webhooks.constructEvent(
      req.body,
      sig as string,
      webhookSecret,
    )
  } catch (err: any) {
    console.error('Webhook signature verification failed', err?.message)
    return res.status(400).send(`Webhook Error: ${err.message}`)
  }

  if (event.type === 'payment_intent.succeeded') {
    const intent = event.data.object as Stripe.PaymentIntent
    const metadata = intent.metadata || {}

    try {
      const items: PaymentLineItem[] = metadata.items
        ? JSON.parse(metadata.items)
        : []

      if (!items.length) {
        console.warn('Webhook: no items in metadata, skipping order creation')
      } else {
        const subtotal =
          typeof intent.amount_received === 'number'
            ? intent.amount_received / 100
            : items.reduce(
                (sum, i) => sum + i.price * i.quantity,
                0,
              )

        await Order.create({
          orderNumber: generateOrderNumber(),
          items: items.map((i) => ({
            menuItemId: i.id,
            name: i.name,
            price: i.price,
            quantity: i.quantity,
          })),
          subtotal,

          paymentMethod: 'card',
          paymentStatus: 'Paid',
          isPaidOnline: true,

          status: 'Pending',

          customerName: metadata.customerName || 'Guest',
          customerEmail: metadata.customerEmail,
          customerPhone: metadata.customerPhone,
          notes: metadata.notes,

          userId: metadata.userId || undefined,
        })
      }
    } catch (err) {
      console.error('Failed to create order from payment_intent', err)
      // still return 200 so Stripe doesn’t retry forever – you can change this if you want
    }
  }

  res.json({ received: true })
}
