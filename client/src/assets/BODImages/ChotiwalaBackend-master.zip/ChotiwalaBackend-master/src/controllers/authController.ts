import { Response } from 'express'
import { AuthRequest } from '../middleware/auth'
import { User } from '../models/User'
import { signJwt } from '../utils/jwt'

const ADMIN_EMAILS = ['adminx@gmail.com'] // keep in sync with frontend

const isAdminEmail = (email: string): boolean =>
  ADMIN_EMAILS.includes(email.toLowerCase())

/**
 * POST /api/auth/sync
 * Body: { email, name, provider, avatarUrl? }
 *
 * Upserts the user in Mongo and returns { token, user }.
 * Frontend should call this after Google/email login.
 */
export const syncUser = async (req: AuthRequest, res: Response) => {
  const { email, name, provider, avatarUrl } = req.body

  if (!email || !name || !provider) {
    return res
      .status(400)
      .json({ message: 'email, name and provider are required' })
  }

  const role = isAdminEmail(email) ? 'admin' : 'customer'

  const user = await User.findOneAndUpdate(
    { email: email.toLowerCase() },
    {
      name,
      email: email.toLowerCase(),
      avatarUrl,
      provider,
      role,
    },
    {
      new: true,
      upsert: true,
      setDefaultsOnInsert: true,
    },
  )

  const token = signJwt({
    sub: user.id,
    email: user.email,
    role: user.role,
  })

  return res.json({
    token,
    user: {
      id: user.id,
      name: user.name,
      email: user.email,
      avatarUrl: user.avatarUrl,
      provider: user.provider,
      role: user.role,
    },
  })
}
