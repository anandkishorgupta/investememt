import { Request, Response } from 'express'
import { Order } from '../models/Order'

/**
 * GET /api/admin/orders
 * Optional query params:
 *  - status=Pending|Preparing|Ready|Completed|Cancelled
 *  - paymentMethod=cash|card
 *  - isPaidOnline=true|false
 *  - limit=50 (default 100)
 */
export const listOrdersAdmin = async (req: Request, res: Response) => {
  try {
    const {
      status,
      paymentMethod,
      isPaidOnline,
      limit = '100',
    } = req.query as {
      status?: string
      paymentMethod?: string
      isPaidOnline?: string
      limit?: string
    }

    const filters: Record<string, any> = {}

    if (status) filters.status = status
    if (paymentMethod) filters.paymentMethod = paymentMethod
    if (typeof isPaidOnline === 'string') {
      // "true" / "false" -> boolean
      filters.isPaidOnline = isPaidOnline === 'true'
    }

    const max = Math.min(parseInt(limit || '100', 10) || 100, 200)

    const orders = await Order.find(filters)
      .sort({ createdAt: -1 }) // newest first
      .limit(max)
      .lean()

    res.json({ orders })
  } catch (err) {
    console.error('Admin: failed to list orders', err)
    res.status(500).json({ message: 'Failed to list orders' })
  }
}

/**
 * PATCH /api/admin/orders/:id/status
 * Body: { status: "Preparing" | "Ready" | "Completed" | "Cancelled" }
 * `id` can be a Mongo _id OR an orderNumber like "MH-ABC123".
 */
export const updateOrderStatus = async (req: Request, res: Response) => {
  try {
    const { id } = req.params
    const { status, paymentStatus } = req.body as {
      status?: string
      paymentStatus?: string
    }

    if (!status && !paymentStatus) {
      return res
        .status(400)
        .json({ message: 'status or paymentStatus is required' })
    }

    // Try by _id first, then by orderNumber
    let order = await Order.findById(id)

    if (!order) {
      order = await Order.findOne({ orderNumber: id })
    }

    if (!order) {
      return res.status(404).json({ message: 'Order not found' })
    }

    if (status) order.status = status as any
    if (paymentStatus) order.paymentStatus = paymentStatus as any

    await order.save()

    res.json(order)
  } catch (err) {
    console.error('Admin: failed to update order status', err)
    res.status(500).json({ message: 'Failed to update order status' })
  }
}
