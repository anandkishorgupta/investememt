// import { Request, Response } from 'express'
// import { MenuSection } from '../models/MenuSection'
// import { MenuItem } from '../models/MenuItem'

// /**
//  * GET /api/menu
//  * Public menu for customers: returns { sections: MenuSection[] } in the same
//  * shape as your current frontend `menuSections` constant.
//  */
// export const getPublicMenu = async (_req: Request, res: Response) => {
//   const sections = await MenuSection.find().sort({ title: 1 }).lean()
//   const items = await MenuItem.find().lean()

//   const itemsBySection = new Map<string, any[]>()
//   items.forEach((item) => {
//     const arr = itemsBySection.get(item.sectionId) ?? []
//     arr.push({
//       id: item.id,
//       name: item.name,
//       description: item.description,
//       price: item.price,
//       spiceLevel: item.spiceLevel,
//       tags: item.tags
//     })
//     itemsBySection.set(item.sectionId, arr)
//   })

//   const payload = sections.map((section) => ({
//     id: section.id,
//     title: section.title,
//     badge: section.badge,
//     icon: section.icon,
//     items: itemsBySection.get(section.id) ?? []
//   }))

//   res.json({ sections: payload })
// }

// // ----------------- Admin menu endpoints -------------------

// export const listMenuItemsAdmin = async (_req: Request, res: Response) => {
//   const sections = await MenuSection.find().sort({ title: 1 }).lean()
//   const items = await MenuItem.find().lean()

//   res.json({ sections, items })
// }

// export const createMenuItem = async (req: Request, res: Response) => {
//   const { id, sectionId, name, description, price, spiceLevel, tags } = req.body

//   if (!sectionId || !name || typeof price !== 'number') {
//     return res
//       .status(400)
//       .json({ message: 'sectionId, name and price are required' })
//   }

//   const itemId = id || `${sectionId}-${Date.now()}`
//   const item = await MenuItem.create({
//     id: itemId,
//     sectionId,
//     name,
//     description,
//     price,
//     spiceLevel,
//     tags
//   })

//   res.status(201).json(item)
// }

// export const updateMenuItem = async (req: Request, res: Response) => {
//   const { id } = req.params
//   const update = req.body

//   const item = await MenuItem.findOneAndUpdate({ id }, update, {
//     new: true
//   })

//   if (!item) return res.status(404).json({ message: 'Menu item not found' })

//   res.json(item)
// }

// export const deleteMenuItem = async (req: Request, res: Response) => {
//   const { id } = req.params
//   const item = await MenuItem.findOneAndDelete({ id })
//   if (!item) return res.status(404).json({ message: 'Menu item not found' })
//   res.json({ message: 'Deleted' })
// }

// backend/src/controllers/menuController.ts
import { Request, Response } from 'express'
import { MenuSection } from '../models/MenuSection'

// GET /api/menu
export const getPublicMenu = async (_req: Request, res: Response) => {
  try {
    const sections = await MenuSection.find().sort({ sortOrder: 1 }).lean()
    res.json({ sections })
  } catch (err) {
    console.error('Failed to load menu', err)
    res.status(500).json({ message: 'Failed to load menu' })
  }
}

// Admin – list all sections + items
export const listMenuItemsAdmin = async (_req: Request, res: Response) => {
  try {
    const sections = await MenuSection.find().sort({ sortOrder: 1 }).lean()
    res.json({ sections })
  } catch (err) {
    console.error('Failed to list menu items', err)
    res.status(500).json({ message: 'Failed to list menu items' })
  }
}

export const createMenuItem = async (req: Request, res: Response) => {
  try {
    const { sectionId, name, description, price, featured } = req.body

    if (!sectionId || !name || typeof price !== 'number') {
      return res.status(400).json({ message: 'Missing required fields' })
    }

    const section = await MenuSection.findOne({ id: sectionId })
    if (!section) {
      return res.status(404).json({ message: 'Section not found' })
    }

    const newItemId = name
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/(^-|-$)+/g, '')

    section.items.push({
      id: newItemId,
      name,
      description,
      price,
      // you can later use `featured` or tags/spiceLevel if you like
    })

    await section.save()

    const sections = await MenuSection.find().sort({ sortOrder: 1 }).lean()
    res.json({ sections })
  } catch (err) {
    console.error('Failed to create menu item', err)
    res.status(500).json({ message: 'Failed to create menu item' })
  }
}

export const updateMenuItem = async (req: Request, res: Response) => {
  try {
    const { id } = req.params
    const { sectionId, name, description, price } = req.body

    const section = await MenuSection.findOne({ id: sectionId })
    if (!section) {
      return res.status(404).json({ message: 'Section not found' })
    }

    const item = section.items.find((i) => i.id === id)
    if (!item) {
      return res.status(404).json({ message: 'Item not found' })
    }

    if (name) item.name = name
    if (description !== undefined) item.description = description
    if (price !== undefined) item.price = price

    await section.save()
    const sections = await MenuSection.find().sort({ sortOrder: 1 }).lean()
    res.json({ sections })
  } catch (err) {
    console.error('Failed to update menu item', err)
    res.status(500).json({ message: 'Failed to update menu item' })
  }
}

export const deleteMenuItem = async (req: Request, res: Response) => {
  try {
    const { id } = req.params
    const { sectionId } = req.body

    const section = await MenuSection.findOne({ id: sectionId })
    if (!section) {
      return res.status(404).json({ message: 'Section not found' })
    }

    section.items = section.items.filter((i) => i.id !== id)
    await section.save()

    const sections = await MenuSection.find().sort({ sortOrder: 1 }).lean()
    res.json({ sections })
  } catch (err) {
    console.error('Failed to delete menu item', err)
    res.status(500).json({ message: 'Failed to delete menu item' })
  }
}
