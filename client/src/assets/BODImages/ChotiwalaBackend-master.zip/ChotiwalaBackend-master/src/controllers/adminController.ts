// backend/src/controllers/adminController.ts
import { Response } from 'express'
import { AuthRequest } from '../middleware/auth'
import { Order } from '../models/Order'
import type { PipelineStage } from 'mongoose'

// ---- DASHBOARD STATS --------------------------------------------------
// GET /api/admin/stats
export const getOverviewStats = async (req: AuthRequest, res: Response) => {
  // today at midnight
  const now = new Date()
  const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate())

  // All three numbers are computed for *today*
  const [ordersToday, pendingOrders, distinctEmails] = await Promise.all([
    // every order created today
    Order.countDocuments({
      createdAt: { $gte: startOfToday },
    }),

    // orders that are still Pending today
    Order.countDocuments({
      status: 'Pending',
      createdAt: { $gte: startOfToday },
    }),

    // distinct non-empty customerEmail values for today
    Order.distinct('customerEmail', {
      createdAt: { $gte: startOfToday },
      customerEmail: { $ne: null },
    }) as Promise<string[]>,
  ])

  const uniqueCustomers = distinctEmails.filter(Boolean).length

  return res.json({
    ordersToday,
    pendingOrders,
    uniqueCustomers,
  })
}

// ---- CUSTOMERS LIST (for /admin/customers page) -----------------------
// GET /api/admin/customers
export const listCustomers = async (req: AuthRequest, res: Response) => {
  const pipeline: PipelineStage[] = [
    {
      $group: {
        _id: '$customerEmail',
        name: { $first: '$customerName' },
        phone: { $first: '$customerPhone' },
        ordersCount: { $sum: 1 },
        lastOrderAt: { $max: '$createdAt' },
      },
    },
    {
      $match: {
        _id: { $ne: null }, // ignore docs with no email
      },
    },
    {
      $sort: { lastOrderAt: -1 },
    },
  ]

  const result = await Order.aggregate(pipeline)

  const customers = result.map((c: any) => ({
    email: c._id as string,
    name: (c.name as string) || '',
    phone: (c.phone as string) || '',
    ordersCount: c.ordersCount as number,
    lastOrderAt: c.lastOrderAt as Date,
  }))

  return res.json({
    customers,
    total: customers.length,
  })
}
