// import { Schema, model, Document } from 'mongoose'

// export interface IMenuSection extends Document {
//   id: string
//   title: string
//   badge?: string
//   icon?: string
//   createdAt: Date
//   updatedAt: Date
// }

// const MenuSectionSchema = new Schema<IMenuSection>(
//   {
//     id: { type: String, required: true, unique: true },
//     title: { type: String, required: true },
//     badge: String,
//     icon: String
//   },
//   { timestamps: true }
// )

// export const MenuSection = model<IMenuSection>('MenuSection', MenuSectionSchema)
// backend/src/models/MenuSection.ts
import { Schema, model, Document } from 'mongoose'

export interface IMenuItem {
  id: string
  name: string
  description?: string
  price: number
  spiceLevel?: 0 | 1 | 2 | 3
  tags?: string[]
}

export interface IMenuSection extends Document {
  id: string
  title: string
  badge?: string
  icon?: string
  items: IMenuItem[]
  sortOrder?: number
}

const MenuItemSchema = new Schema<IMenuItem>(
  {
    id: { type: String, required: true },
    name: { type: String, required: true },
    description: String,
    price: { type: Number, required: true },
    spiceLevel: { type: Number, min: 0, max: 3 },
    tags: [String],
  },
  { _id: false }
)

const MenuSectionSchema = new Schema<IMenuSection>({
  id: { type: String, required: true, unique: true }, // "paneer", "veg-curries", etc
  title: { type: String, required: true },
  badge: String,
  icon: String,
  items: { type: [MenuItemSchema], default: [] },
  sortOrder: { type: Number, default: 0 },
})

export const MenuSection = model<IMenuSection>('MenuSection', MenuSectionSchema)
