import { Schema, model, Document, Types } from 'mongoose'

export type PaymentMethod = 'cash' | 'card'
export type PaymentStatus = 'Pending' | 'Paid' | 'Failed'
export type OrderStatus = 'Pending' | 'Completed'

export interface IOrderItem {
  menuItemId: string
  name: string
  price: number
  quantity: number
}

export interface IOrder extends Document {
  orderNumber: string
  items: IOrderItem[]
  subtotal: number
  paymentMethod: PaymentMethod
  paymentStatus: PaymentStatus
  isPaidOnline: boolean
  status: OrderStatus
  customerName: string
  customerEmail?: string
  customerPhone?: string
  notes?: string
  userId?: Types.ObjectId | null
  createdAt: Date
  updatedAt: Date
}

const orderItemSchema = new Schema<IOrderItem>(
  {
    menuItemId: { type: String, required: true },
    name: { type: String, required: true },
    price: { type: Number, required: true },
    quantity: { type: Number, required: true },
  },
  { _id: false },
)

const orderSchema = new Schema<IOrder>(
  {
    orderNumber: { type: String, required: true, unique: true },
    items: { type: [orderItemSchema], required: true },
    subtotal: { type: Number, required: true },

    paymentMethod: {
      type: String,
      enum: ['cash', 'card'],
      required: true,
    },
    paymentStatus: {
      type: String,
      enum: ['Pending', 'Paid', 'Failed'],
      required: true,
      default: 'Pending',
    },
    isPaidOnline: { type: Boolean, required: true, default: false },

    status: {
      type: String,
      enum: ['Pending', 'Completed'],
      required: true,
      default: 'Pending',
      index: true,
    },

    customerName: { type: String, required: true },
    customerEmail: { type: String },
    customerPhone: { type: String },
    notes: { type: String },

    userId: { type: Schema.Types.ObjectId, ref: 'User', index: true },
  },
  { timestamps: true },
)

orderSchema.index({ createdAt: -1 })

export const Order = model<IOrder>('Order', orderSchema)
