import { Schema, model, Document } from 'mongoose'

export interface IMenuItem extends Document {
  id: string
  sectionId: string
  name: string
  description?: string
  price: number
  spiceLevel?: 0 | 1 | 2 | 3
  tags?: string[]
  createdAt: Date
  updatedAt: Date
}

const MenuItemSchema = new Schema<IMenuItem>(
  {
    id: { type: String, required: true, unique: true },
    sectionId: { type: String, required: true },
    name: { type: String, required: true },
    description: String,
    price: { type: Number, required: true },
    spiceLevel: { type: Number, min: 0, max: 3 },
    tags: [String]
  },
  { timestamps: true }
)

export const MenuItem = model<IMenuItem>('MenuItem', MenuItemSchema)
